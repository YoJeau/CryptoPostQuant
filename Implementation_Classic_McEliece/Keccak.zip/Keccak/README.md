This folder have the goal to replace installing a library for running mceliece reference implementation.
If you install this, place this folder in any implementation of your choice, modify crypto_hash.h of your implementation and include "Keccak/SimpleFIPS202.h" instead.
Then, modify the build script and replace -lkeccak by Keccak/SimpleFIPS202.c Keccak/KeccakSponge.c Keccak/KeccakP-1600-compact64.c

Doing so will also allow you to cross compile this program since this folder is not a compiled library.
