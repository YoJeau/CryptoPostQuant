#ifndef DECRYPT_H
#define DECRYPT_H

using namespace std;

int decrypt(void);

#endif // DECRYPT_H 
