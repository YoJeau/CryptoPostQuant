#ifndef ENCRYPT_H
#define ENCRYPT_H

using namespace std;

int encrypt(void);

#endif // ENCRYPT_H 
