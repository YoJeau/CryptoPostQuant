 #ifndef PK_GEN_H
#define PK_GEN_H

using namespace std;

int pk_gen(void);

#endif // PK_GEN_H
