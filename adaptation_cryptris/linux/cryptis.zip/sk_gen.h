#ifndef SK_GEN_H
#define SK_GEN_H

using namespace std;

int sk_gen(void);

#endif // SK_GEN_H 
