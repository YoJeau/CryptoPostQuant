#ifndef ASCII_TRITS_H
#define ASCII_TRITS_H

using namespace std;

vector<int> asciiToTrits(vector<char> ascii);
vector<char> tritsToAscii(vector<int> trits);

#endif // ASCII_TRITS_H